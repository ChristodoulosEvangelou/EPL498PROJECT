package com.example.project498;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.PopupMenu;

import java.io.Serializable;
import java.util.Random;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainFragment extends Fragment {

    private RecyclerView recyclerView;
    private ShoeAdapter shoeAdapter;
    private List<Shoe> shoeList;
    private List<Shoe> shoeNikeList;
    private List<Shoe> shoeAdidasList;
    private List<Shoe> shoeNewBalanceList;

    private Button buttonAll, buttonNike, buttonAdidas, buttonNewBalance;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_main, container, false);
        setHasOptionsMenu(true);
        // Initialize RecyclerView and lists
        recyclerView = rootView.findViewById(R.id.recyclerView_shoes);
        shoeList = new ArrayList<>();
        shoeNikeList = new ArrayList<>();
        shoeAdidasList = new ArrayList<>();
        shoeNewBalanceList = new ArrayList<>();

        populateAllShoeList();
        populateBrandSpecificLists();

        shoeAdapter = new ShoeAdapter(shoeList, shoe -> {
            Bundle bundle = new Bundle();
            bundle.putSerializable("selectedShoe", (Serializable) shoe);  // Στέλνεις το αντικείμενο Shoe
            Navigation.findNavController(rootView).navigate(R.id.action_MainFragment_to_ShoeDetailFragment, bundle);
        });
        recyclerView.setAdapter(shoeAdapter);

        // Set RecyclerView LayoutManager
        setRecyclerViewLayout();
        ImageButton menuButton = rootView.findViewById(R.id.menuButton); // Find the menu button
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create the PopupMenu and inflate the menu items
                PopupMenu popupMenu = new PopupMenu(getActivity(), v);
                MenuInflater inflater = popupMenu.getMenuInflater();
                inflater.inflate(R.menu.menu_items, popupMenu.getMenu());  // Inflate the menu

                // Handle menu item click
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        NavController navController = Navigation.findNavController(getView());
                        if (item.getItemId() == R.id.menshoes) {
                            navController.navigate(R.id.action_MainFragment_to_MensFragment);
                            return true;
                        } else if (item.getItemId() == R.id.womenshoes) {
                            navController.navigate(R.id.action_MainFragment_to_WomensFragment);
                            return true;
                        } else if (item.getItemId() == R.id.kidshoes) {
                            navController.navigate(R.id.action_MainFragment_to_KidsFragment);
                            return true;
                        } else {
                            return false;
                        }
                    }
                });

                // Show the PopupMenu
                popupMenu.show();
            }
        });

        // Add functionality for ImageButton to navigate to SettingsFragment
        ImageButton settingsButton = rootView.findViewById(R.id.settingsButton);
        settingsButton.setOnClickListener(v -> {
            NavController navController = Navigation.findNavController(rootView);
            navController.navigate(R.id.action_MainFragment_to_SettingsFragment);
        });

        // Add functionality for ImageButton to navigate to SettingsFragment
        ImageButton favouriteButton = rootView.findViewById(R.id.favouriteButton);
        favouriteButton.setOnClickListener(v -> {
            NavController navController = Navigation.findNavController(rootView);
            navController.navigate(R.id.action_MainFragment_to_FavouriteFragment);
        });

        // Initialize buttons
        buttonAll = rootView.findViewById(R.id.button_all);
        buttonNike = rootView.findViewById(R.id.button_nike);
        buttonAdidas = rootView.findViewById(R.id.button_adidas);
        buttonNewBalance = rootView.findViewById(R.id.button_nbalance);

        // Set onClickListeners
        buttonAll.setOnClickListener(view -> {
            showAllShoes();
            changeButtonColor(buttonAll);
        });
        buttonNike.setOnClickListener(view -> {
            showNikeShoes();
            changeButtonColor(buttonNike);
        });
        buttonAdidas.setOnClickListener(view -> {
            showAdidasShoes();
            changeButtonColor(buttonAdidas);
        });
        buttonNewBalance.setOnClickListener(view -> {
            showNewBalanceShoes();
            changeButtonColor(buttonNewBalance);
        });

        return rootView;
    }

    private void setRecyclerViewLayout() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);
    }

    private void populateAllShoeList() {

        shoeList.add(new Shoe("Nike Air Max Excee", R.drawable.airmaxexcee, 135, Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("Nike Air Max 270", R.drawable.airmax270, 130 , Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("Nike v2k", R.drawable.v2knike, 120 , Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("Adidas Yeezy 350 ", R.drawable.yeezy350, 180 , Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("Adidas Samba M.", R.drawable.samba, 150 , Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("Adidas Superstar M.", R.drawable.superstar, 140 , Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("New Balance 990", R.drawable.nbalance990, 140 , Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("New Balance 9060", R.drawable.nb9060, 155 , Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("New Balance 550 M.", R.drawable.nb550nb, 150 , Shoe.ShoeType.MEN));
    }

    private void populateBrandSpecificLists() {

        // Nike shoes
        shoeNikeList.add(new Shoe("Nike Air Max Excee", R.drawable.airmaxexcee, 135, Shoe.ShoeType.MEN));
        shoeNikeList.add(new Shoe("Nike Air Max 270", R.drawable.airmax270, 130 , Shoe.ShoeType.MEN));
        shoeNikeList.add(new Shoe("Nike v2k", R.drawable.v2knike, 120 , Shoe.ShoeType.MEN));

        // Adidas shoes
        shoeAdidasList.add(new Shoe("Adidas Yeezy 350 ", R.drawable.yeezy350, 180 , Shoe.ShoeType.MEN));
        shoeAdidasList.add(new Shoe("Adidas Samba M.", R.drawable.samba, 150 , Shoe.ShoeType.MEN));
        shoeAdidasList.add(new Shoe("Adidas Superstar M.", R.drawable.superstar, 140 , Shoe.ShoeType.MEN));

        // New Balance shoes
        shoeNewBalanceList.add(new Shoe("New Balance 990", R.drawable.nbalance990, 140 , Shoe.ShoeType.MEN));
        shoeNewBalanceList.add(new Shoe("New Balance 9060", R.drawable.nb9060, 155 , Shoe.ShoeType.MEN));
        shoeNewBalanceList.add(new Shoe("New Balance 550 M.", R.drawable.nb550nb, 150 , Shoe.ShoeType.MEN));
    }

    private void showAllShoes() {
        shoeList.clear();
        populateAllShoeList();
        shoeAdapter.notifyDataSetChanged();
    }

    private void showNikeShoes() {
        shoeList.clear();
        shoeList.addAll(shoeNikeList);
        shoeAdapter.notifyDataSetChanged();
    }

    private void showAdidasShoes() {
        shoeList.clear();
        shoeList.addAll(shoeAdidasList);
        shoeAdapter.notifyDataSetChanged();
    }

    private void showNewBalanceShoes() {
        shoeList.clear();
        shoeList.addAll(shoeNewBalanceList);
        shoeAdapter.notifyDataSetChanged();
    }

    private void changeButtonColor(Button button) {
        // Reset all buttons to default color (black)
        resetButtonColors();

        // Set the clicked button color to orange
        button.setBackgroundColor(Color.parseColor("#FFA500"));  // Orange color
    }

    private void resetButtonColors() {
        // Reset the background color of all buttons to black
        buttonAll.setBackgroundColor(Color.parseColor("#000000"));
        buttonNike.setBackgroundColor(Color.parseColor("#000000"));
        buttonAdidas.setBackgroundColor(Color.parseColor("#000000"));
        buttonNewBalance.setBackgroundColor(Color.parseColor("#000000"));
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_main, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
//        if (id == R.id.action_settings) {
//            return true;
//        }
        return super.onOptionsItemSelected(item);
    }
}
