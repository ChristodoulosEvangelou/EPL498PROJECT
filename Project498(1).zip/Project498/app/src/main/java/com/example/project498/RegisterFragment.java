package com.example.project498;

import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.project498.databinding.FragmentRegisterBinding;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

/**
 * This class is responsible for demonstrating firebase features
 */
public class RegisterFragment extends Fragment {

    private FragmentRegisterBinding binding;
    private EditText editConfirmPassword, editTextFullName, editTextEmail, editTextPassword, editTextPhoneNumber;
    private Button buttonSubmit;

    private FirebaseFirestore db;
    private CollectionReference usersCollection;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = FirebaseFirestore.getInstance();
        usersCollection = db.collection("users");
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        // Inflate the binding for this fragment
        binding = FragmentRegisterBinding.inflate(inflater, container, false);

        // Initialize UI elements
        editTextFullName = binding.editTextFullName;
        editTextEmail = binding.editTextEmail;
        editTextPassword = binding.editTextPassword;
        editConfirmPassword = binding.editTextConfirmPassword;
        editTextPhoneNumber = binding.editTextPhoneNumber;
        buttonSubmit = binding.buttonSubmit;

        // Define a click listener for the "Submit" button
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get user input
                String fullName = editTextFullName.getText().toString();
                String email = editTextEmail.getText().toString();
                String password = editTextPassword.getText().toString();
                String confirmPassword = editConfirmPassword.getText().toString();
                String phoneNumber = editTextPhoneNumber.getText().toString();

                // Validate input
                if (TextUtils.isEmpty(fullName) || TextUtils.isEmpty(email) ||
                        TextUtils.isEmpty(password) || TextUtils.isEmpty(phoneNumber) ||
                        TextUtils.isEmpty(confirmPassword)) {
                    Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Check if password and confirmPassword match
                if (!password.equals(confirmPassword)) {
                    Toast.makeText(requireContext(), "Passwords do not match", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Check if email matches the pattern
                if (!email.matches("^[a-zA-Z0-9._%+-]+@gmail\\.com$")) {
                    Toast.makeText(requireContext(), "Please enter a valid email (example@gmail.com)", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Check if email already exists in Firestore
                usersCollection.whereEqualTo("email", email).get()
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful() && !task.getResult().isEmpty()) {
                                // Email already exists
                                Toast.makeText(requireContext(), "This email is already registered", Toast.LENGTH_SHORT).show();
                            } else {
                                // Email does not exist, proceed to create a new user
                                UserObject user = new UserObject(fullName, email, password, phoneNumber);

                                usersCollection.add(user)
                                        .addOnSuccessListener(documentReference -> {
                                            Toast.makeText(requireContext(), "Info Saved Successfully", Toast.LENGTH_SHORT).show();

                                            // Navigate to the next fragment
                                            new Handler().postDelayed(() -> {
                                                String documentReferenceId = documentReference.getId();
                                                Bundle bundle = new Bundle();
                                                bundle.putString("documentReferenceId", documentReferenceId);

                                                NavHostFragment.findNavController(RegisterFragment.this)
                                                        .navigate(R.id.action_RegisterFragment_to_SigninFragment, bundle);
                                            }, 3000);
                                        })
                                        .addOnFailureListener(e -> {
                                            Toast.makeText(requireContext(), "Failure: info was not saved...", Toast.LENGTH_LONG).show();
                                        });
                            }
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(requireContext(), "Error checking email", Toast.LENGTH_SHORT).show();
                        });
            }
        });

        return binding.getRoot();
    }
}
