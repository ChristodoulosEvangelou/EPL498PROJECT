package com.example.project498;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ShoeAdapter extends RecyclerView.Adapter<ShoeAdapter.ShoeViewHolder> {

    private List<Shoe> shoeList;
    private OnShoeClickListener listener;

    public ShoeAdapter(List<Shoe> shoeList, OnShoeClickListener listener) {
        this.shoeList = shoeList;
        this.listener = listener;
    }

    public static class ShoeViewHolder extends RecyclerView.ViewHolder {
        public TextView shoeName;
        public ImageView shoeImage;
        public TextView shoePrice;

        public ShoeViewHolder(View view) {
            super(view);
            shoeName = view.findViewById(R.id.shoe_name);
            shoeImage = view.findViewById(R.id.shoe_image);
            shoePrice = view.findViewById(R.id.shoe_price);
        }

        public void bind(final Shoe shoe, final OnShoeClickListener listener) {
            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onShoeClick(shoe);
                }
            });
        }
    }

    public interface OnShoeClickListener {
        void onShoeClick(Shoe shoe);
    }

    @NonNull
    @Override
    public ShoeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_shoe, parent, false);
        return new ShoeViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ShoeViewHolder holder, int position) {
        Shoe shoe = shoeList.get(position);
        holder.shoeName.setText(shoe.getName());
        holder.shoeImage.setImageResource(shoe.getImageResId());
        holder.shoePrice.setText(String.format("%s €", shoe.getPrice()));
        holder.bind(shoe, listener);  // Bind the shoe and listener
    }

    @Override
    public int getItemCount() {
        return shoeList.size();
    }
}
