package com.example.project498;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.Toast;
import androidx.navigation.fragment.NavHostFragment;
import com.example.project498.databinding.FragmentSigninBinding;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;


public class SigninFragment extends Fragment {

    private FragmentSigninBinding binding;
    private EditText editTextEmail, editTextPassword;
    private Button buttonSignIn;
    public static String userEmail;
    private FirebaseFirestore db;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = FirebaseFirestore.getInstance(); // Initialize Firestore
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        // Inflate the binding for this fragment
        binding = FragmentSigninBinding.inflate(inflater, container, false);

        // Initialize UI elements from the XML layout
        editTextEmail = binding.getRoot().findViewById(R.id.editTextEmail);
        editTextPassword = binding.getRoot().findViewById(R.id.editTextPassword);
        buttonSignIn = binding.getRoot().findViewById(R.id.buttonSignIn);

        // Define click listener for the "Sign In" button
        buttonSignIn.setOnClickListener(v -> {
            // Get user input
            String email = editTextEmail.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            // Validate input
            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
                Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Query Firestore to check if the user exists
            db.collection("users")
                    .whereEqualTo("email", email)
                    .get()
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            boolean userFound = false;
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String storedPassword = document.getString("password");

                                if (storedPassword != null && storedPassword.equals(password)) {
                                    userFound = true;
                                    userEmail = email;
                                    // Navigate to MainFragment
                                    NavHostFragment.findNavController(SigninFragment.this)
                                            .navigate(R.id.action_SigninFragment_to_MainFragment);
                                    break;
                                }
                            }

                            if (!userFound) {
                                Toast.makeText(requireContext(), "Invalid email or password", Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(requireContext(), "Error checking user: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
        });

        return binding.getRoot();
    }
}
