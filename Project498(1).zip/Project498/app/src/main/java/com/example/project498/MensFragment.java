package com.example.project498;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;


public class MensFragment extends Fragment implements ShoeAdapter.OnShoeClickListener {

    private RecyclerView recyclerView;
    private ShoeAdapter shoeAdapter;
    private List<Shoe> shoeList;
    private List<Shoe> shoeNikeList;
    private List<Shoe> shoeAdidasList;
    private List<Shoe> shoeNewBalanceList;

    private Button buttonAll, buttonNike, buttonAdidas, buttonNewBalance;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_mens, container, false);
        TextView textView = rootView.findViewById(R.id.textView);
        textView.setText("Men's Collection");

        // Initialize RecyclerView and lists
        recyclerView = rootView.findViewById(R.id.recyclerView_shoes);
        shoeList = new ArrayList<>();
        shoeNikeList = new ArrayList<>();
        shoeAdidasList = new ArrayList<>();
        shoeNewBalanceList = new ArrayList<>();

        populateAllShoeList();
        populateBrandSpecificLists();

        // Set up the Adapter for RecyclerView
        shoeAdapter = new ShoeAdapter(shoeList, this);  // Pass `this` as the listener
        recyclerView.setAdapter(shoeAdapter);

        // Set RecyclerView LayoutManager
        setRecyclerViewLayout();

        // Initialize buttons
        buttonAll = rootView.findViewById(R.id.button_all);
        buttonNike = rootView.findViewById(R.id.button_nike);
        buttonAdidas = rootView.findViewById(R.id.button_adidas);
        buttonNewBalance = rootView.findViewById(R.id.button_nbalance);

        // Set onClickListeners
        buttonAll.setOnClickListener(view -> {
            showAllShoes();
            changeButtonColor(buttonAll);
        });
        buttonNike.setOnClickListener(view -> {
            showNikeShoes();
            changeButtonColor(buttonNike);
        });
        buttonAdidas.setOnClickListener(view -> {
            showAdidasShoes();
            changeButtonColor(buttonAdidas);
        });
        buttonNewBalance.setOnClickListener(view -> {
            showNewBalanceShoes();
            changeButtonColor(buttonNewBalance);
        });

        return rootView;
    }

    private void setRecyclerViewLayout() {
        // Set GridLayoutManager with 2 columns
        GridLayoutManager layoutManager = new GridLayoutManager(getContext(), 2);
        recyclerView.setLayoutManager(layoutManager);
    }

    private void populateAllShoeList() {

        shoeList.add(new Shoe("Nike Air Max Excee", R.drawable.airmaxexcee, 135, Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("Nike Air Max 270", R.drawable.airmax270, 130 , Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("Nike v2k", R.drawable.v2knike, 120 , Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("Adidas Yeezy 350 ", R.drawable.yeezy350, 180 , Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("Adidas Samba M.", R.drawable.samba, 150 , Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("Adidas Superstar M.", R.drawable.superstar, 140 , Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("New Balance 990", R.drawable.nbalance990, 140 , Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("New Balance 9060", R.drawable.nb9060, 155 , Shoe.ShoeType.MEN));
        shoeList.add(new Shoe("New Balance 550 M.", R.drawable.nb550nb, 150 , Shoe.ShoeType.MEN));
    }

    private void populateBrandSpecificLists() {

        // Nike shoes
        shoeNikeList.add(new Shoe("Nike Air Max Excee", R.drawable.airmaxexcee, 135, Shoe.ShoeType.MEN));
        shoeNikeList.add(new Shoe("Nike Air Max 270", R.drawable.airmax270, 130 , Shoe.ShoeType.MEN));
        shoeNikeList.add(new Shoe("Nike v2k", R.drawable.v2knike, 120 , Shoe.ShoeType.MEN));

        // Adidas shoes
        shoeAdidasList.add(new Shoe("Adidas Yeezy 350 ", R.drawable.yeezy350, 180 , Shoe.ShoeType.MEN));
        shoeAdidasList.add(new Shoe("Adidas Samba M.", R.drawable.samba, 150 , Shoe.ShoeType.MEN));
        shoeAdidasList.add(new Shoe("Adidas Superstar M.", R.drawable.superstar, 140 , Shoe.ShoeType.MEN));

        // New Balance shoes
        shoeNewBalanceList.add(new Shoe("New Balance 990", R.drawable.nbalance990, 140 , Shoe.ShoeType.MEN));
        shoeNewBalanceList.add(new Shoe("New Balance 9060", R.drawable.nb9060, 155 , Shoe.ShoeType.MEN));
        shoeNewBalanceList.add(new Shoe("New Balance 550 M.", R.drawable.nb550nb, 150 , Shoe.ShoeType.MEN));
    }


    private void showAllShoes() {
        shoeList.clear();
        populateAllShoeList();
        shoeAdapter.notifyDataSetChanged();
    }

    private void showNikeShoes() {
        shoeList.clear();
        shoeList.addAll(shoeNikeList);
        shoeAdapter.notifyDataSetChanged();
    }

    private void showAdidasShoes() {
        shoeList.clear();
        shoeList.addAll(shoeAdidasList);
        shoeAdapter.notifyDataSetChanged();
    }

    private void showNewBalanceShoes() {
        shoeList.clear();
        shoeList.addAll(shoeNewBalanceList);
        shoeAdapter.notifyDataSetChanged();
    }

    private void changeButtonColor(Button selectedButton) {
        buttonAll.setBackgroundColor(Color.parseColor("#000000"));
        buttonNike.setBackgroundColor(Color.parseColor("#000000"));
        buttonAdidas.setBackgroundColor(Color.parseColor("#000000"));
        buttonNewBalance.setBackgroundColor(Color.parseColor("#000000"));

        selectedButton.setBackgroundColor(Color.parseColor("#FF0000"));
    }

    @Override
    public void onShoeClick(Shoe shoe) {
        // Δημιουργία του ShoeDetailFragment και περασμα των δεδομένων
        ShoeDetailFragment shoeDetailFragment = new ShoeDetailFragment();
        Bundle args = new Bundle();
        args.putSerializable("selectedShoe", shoe);  // Προσθέστε το Shoe object
        shoeDetailFragment.setArguments(args);

        // Χρησιμοποιούμε το NavController για να πλοηγηθούμε στο νέο fragment
        NavController navController = NavHostFragment.findNavController(this); // Αυτό πρέπει να το κάνετε μέσα στο Fragment
        navController.navigate(R.id.action_MenFragment_to_ShoeDetailFragment, args);
    }
}
