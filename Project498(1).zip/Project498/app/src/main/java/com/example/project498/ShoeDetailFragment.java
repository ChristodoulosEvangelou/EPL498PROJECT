package com.example.project498;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class ShoeDetailFragment extends Fragment {

    private ImageView shoeImage;
    private TextView shoeName;
    private TextView shoePrice;
    private Button buttonShowMap;
    private Button sizeButton1, sizeButton2, sizeButton3;
    private Shoe shoe;
    private ImageButton settingsFavourite;
    private FirebaseFirestore db;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout
        View rootView = inflater.inflate(R.layout.fragment_shoe_detail, container, false);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Retrieve UI elements
        shoeImage = rootView.findViewById(R.id.shoe_image);
        shoeName = rootView.findViewById(R.id.shoe_name);
        shoePrice = rootView.findViewById(R.id.shoe_price);
        buttonShowMap = rootView.findViewById(R.id.button_show_map);
        sizeButton1 = rootView.findViewById(R.id.size_1);
        sizeButton2 = rootView.findViewById(R.id.size_2);
        sizeButton3 = rootView.findViewById(R.id.size_3);
        settingsFavourite = rootView.findViewById(R.id.settingsFavourite);

        // Set default color for all size buttons
        sizeButton1.setBackgroundColor(getResources().getColor(R.color.button_default));
        sizeButton2.setBackgroundColor(getResources().getColor(R.color.button_default));
        sizeButton3.setBackgroundColor(getResources().getColor(R.color.button_default));

        // Set the OnClickListener for each size button
        sizeButton1.setOnClickListener(v -> changeButtonColor(sizeButton1));
        sizeButton2.setOnClickListener(v -> changeButtonColor(sizeButton2));
        sizeButton3.setOnClickListener(v -> changeButtonColor(sizeButton3));

        // Retrieve shoe object from the bundle
        Bundle bundle = getArguments();
        if (bundle != null) {
            shoe = (Shoe) bundle.getSerializable("selectedShoe");

            if (shoe != null) {
                // Set shoe details in the UI
                shoeName.setText(shoe.getName());
                shoeImage.setImageResource(shoe.getImageResId()); // Make sure the shoe image resource is correct
                shoePrice.setText(String.format("€ %d ", shoe.getPrice()));

                // Set size options based on shoe type
                Random random = new Random();
                switch (shoe.getType()) {
                    case MEN:
                        int[] menSizes = {40, 41, 42, 43, 44, 45, 46};
                        //shuffleArray(menSizes);
                        sizeButton1.setText(String.valueOf(menSizes[0]));
                        sizeButton2.setText(String.valueOf(menSizes[1]));
                        sizeButton3.setText(String.valueOf(menSizes[2]));
                        break;
                    case WOMEN:
                        double[] womenSizes = {36, 36.5, 37, 37.5, 38, 38.5, 39, 39.5, 40};
                        // shuffleArray(womenSizes);
                        sizeButton1.setText(String.valueOf(womenSizes[0]));
                        sizeButton2.setText(String.valueOf(womenSizes[1]));
                        sizeButton3.setText(String.valueOf(womenSizes[2]));
                        break;
                    case KIDS:
                        int[] kidsSizes = {30, 31, 32, 33, 34};
                        //shuffleArray(kidsSizes);
                        sizeButton1.setText(String.valueOf(kidsSizes[0]));
                        sizeButton2.setText(String.valueOf(kidsSizes[1]));
                        sizeButton3.setText(String.valueOf(kidsSizes[2]));
                        break;
                }
            }
        }

        // Listener for the "Show Map" button
        buttonShowMap.setOnClickListener(v ->
                Navigation.findNavController(rootView).navigate(R.id.action_ShoeDetailFragment_to_AvailableShopsFragment)
        );

        // Listener for the favourite button
        settingsFavourite.setOnClickListener(v -> addShoeToFavourites());

        return rootView;
    }

    private void changeButtonColor(Button selectedButton) {
        // Reset all buttons to default color
        sizeButton1.setBackgroundColor(getResources().getColor(R.color.button_default));
        sizeButton2.setBackgroundColor(getResources().getColor(R.color.button_default));
        sizeButton3.setBackgroundColor(getResources().getColor(R.color.button_default));

        // Change the selected button color to pink (or your chosen color)
        selectedButton.setBackgroundColor(getResources().getColor(R.color.button_pressed));
    }

    private void addShoeToFavourites() {
        if (shoe == null) {
            Toast.makeText(getContext(), "No shoe selected", Toast.LENGTH_SHORT).show();
            return;
        }

        // Retrieve user email
        String userEmail = SigninFragment.userEmail; // Static variable from SignInFragment

        // Reference to the document in Firestore
        db.collection("favourites").document(userEmail)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        // If the document exists, retrieve the existing shoes
                        List<Map<String, Object>> existingShoes = (List<Map<String, Object>>) documentSnapshot.get("shoes");
                        if (existingShoes == null) {
                            existingShoes = new ArrayList<>();
                        }

                        // Check if the shoe already exists (based on its name and price)
                        for (Map<String, Object> existingShoe : existingShoes) {
                            if (existingShoe.get("name").equals(shoe.getName()) &&
                                    ((Long) existingShoe.get("price")).intValue() == shoe.getPrice()) {
                                Toast.makeText(getContext(), "Already exists in favourites", Toast.LENGTH_SHORT).show();
                                return;
                            }
                        }

                        // If not, add it to the list
                        Map<String, Object> newShoe = new HashMap<>();
                        newShoe.put("name", shoe.getName());
                        newShoe.put("price", shoe.getPrice());
                        newShoe.put("imageResId", shoe.getImageResId());
                        newShoe.put("type", shoe.getType().name());
                        existingShoes.add(newShoe);

                        db.collection("favourites").document(userEmail)
                                .update("shoes", existingShoes)
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(getContext(), "Added to favourites", Toast.LENGTH_SHORT).show();
                                    Navigation.findNavController(requireView()).navigate(R.id.action_ShoeDetailFragment_to_FavouriteFragment);
                                })
                                .addOnFailureListener(e -> Toast.makeText(getContext(), "Failed to add to favourites", Toast.LENGTH_SHORT).show());
                    } else {
                        // If the document doesn't exist, create it with the new shoe
                        Map<String, Object> newShoe = new HashMap<>();
                        newShoe.put("name", shoe.getName());
                        newShoe.put("price", shoe.getPrice());
                        newShoe.put("imageResId", shoe.getImageResId());
                        newShoe.put("type", shoe.getType().name());

                        Map<String, Object> data = new HashMap<>();
                        data.put("email", userEmail);
                        data.put("shoes", List.of(newShoe));

                        db.collection("favourites").document(userEmail)
                                .set(data)
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(getContext(), "Added to favourites", Toast.LENGTH_SHORT).show();
                                    Navigation.findNavController(requireView()).navigate(R.id.action_ShoeDetailFragment_to_FavouriteFragment);
                                })
                                .addOnFailureListener(e -> Toast.makeText(getContext(), "Failed to add to favourites", Toast.LENGTH_SHORT).show());
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(getContext(), "Failed to retrieve favourites", Toast.LENGTH_SHORT).show());
    }

    private void shuffleArray(int[] array) {
        Random random = new Random();
        for (int i = array.length - 1; i > 0; i--) {
            int index = random.nextInt(i + 1);
            int temp = array[index];
            array[index] = array[i];
            array[i] = temp;
        }
    }

    private void shuffleArray(double[] array) {
        Random random = new Random();
        for (int i = array.length - 1; i > 0; i--) {
            int index = random.nextInt(i + 1);
            double temp = array[index];
            array[index] = array[i];
            array[i] = temp;
        }
    }
}
