package com.example.project498;

import java.io.Serializable;

public class Shoe implements Serializable {

    public enum ShoeType {
        MEN, WOMEN, KIDS
    }

    private String name;
    private int imageResId;
    private int price;
    private ShoeType type;

    public Shoe() {
    }


    // Constructor
    public Shoe(String name, int imageResId, int price, ShoeType type) {
        this.name = name;
        this.imageResId = imageResId;
        this.price = price;
        this.type = type;
    }

    // Getters
    public String getName() {
        return name;
    }

    public int getImageResId() {
        return imageResId;
    }

    public int getPrice() {
        return price;
    }

    public ShoeType getType() {
        return type;
    }
}
