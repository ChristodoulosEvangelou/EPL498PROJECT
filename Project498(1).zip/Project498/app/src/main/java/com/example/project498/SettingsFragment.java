package com.example.project498;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import com.example.project498.databinding.FragmentSettingsBinding;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;

public class SettingsFragment extends Fragment {

    private FragmentSettingsBinding binding;
    private FirebaseFirestore db;

    private TextView textViewFullName, textViewEmail, textViewPhoneNumber;
    private Button buttonEdit;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = FirebaseFirestore.getInstance(); // Initialize Firestore
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSettingsBinding.inflate(inflater, container, false);

        textViewFullName = binding.textViewFullName;
        textViewEmail = binding.textViewEmail;
        textViewPhoneNumber = binding.textViewPhoneNumber;
        buttonEdit = binding.buttonEdit;

        // Get the email from the static variable in SigninFragment
        String email = SigninFragment.userEmail;
        if (email != null && !email.isEmpty()) {
            fetchUserData(email);
        } else {
            Toast.makeText(requireContext(), "Email not found!", Toast.LENGTH_SHORT).show();
        }

        // Set OnClickListener for Edit button
        buttonEdit.setOnClickListener(v -> {
            // Navigate to EditFragment using NavController
            if (SigninFragment.userEmail != null && !SigninFragment.userEmail.isEmpty()) {
                Bundle bundle = new Bundle();
                bundle.putString("email", SigninFragment.userEmail); // Pass user email to EditFragment

                // Navigate to EditFragment
                Navigation.findNavController(v).navigate(R.id.action_SettingsFragment_to_EditFragment, bundle);
            } else {
                Toast.makeText(requireContext(), "User email is not available", Toast.LENGTH_SHORT).show();
            }
        });

        return binding.getRoot();
    }

    private void fetchUserData(String email) {
        db.collection("users")
                .whereEqualTo("email", email)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        // Assuming there is only one document with the same email
                        for (DocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                            String fullName = documentSnapshot.getString("fullName");
                            String phoneNumber = documentSnapshot.getString("phoneNumber");

                            // Set the user data in the TextViews
                            textViewFullName.setText("Full Name: " + fullName);
                            textViewEmail.setText("Email: " + email);  // Display the email
                            textViewPhoneNumber.setText("Phone Number: " + phoneNumber);
                        }
                    } else {
                        Toast.makeText(requireContext(), "User data not found!", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(requireContext(), "Error fetching data: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }
}
